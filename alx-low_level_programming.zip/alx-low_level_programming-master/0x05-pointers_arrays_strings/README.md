Pointers, arrays and strings
