#include<stdio.h>
/**
 * main - Aprogram that prints a line with pritf function
 *
 * Return: 0 (Sucess)
 */
int main(void)
{
	printf("with proper grammar, but the outcome is a piece of art,\n");
		return (0);
}
